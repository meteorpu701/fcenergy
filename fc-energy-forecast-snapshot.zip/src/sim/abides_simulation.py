# src/abides_simulation.py

from __future__ import annotations

from pathlib import Path
import pandas as pd

from abides_core import abides
from abides_markets.configs import rmsc04

from src.extract_agent_features import extract_agent_features
from src.hub_price_loader import get_price_for_hub_date

SCALE = 10_000

# where outputs go
OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "simulated_trades"


def get_r_bar_for_date(date: str, hub: str = "TTF", prices_csv: str = "data/eu_hub_prices.csv") -> float:
    """
    Returns oracle fundamental mean (r_bar) in ABIDES price units.
    """
    p = float(get_price_for_hub_date(hub=hub, date_str=date, csv_path=prices_csv))
    return p * SCALE


def run_rmsc04_simulation(date: str, hub: str = "TTF", prices_csv: str = "data/eu_hub_prices.csv"):
    """
    Runs one ABIDES simulation day.

    We try to pass (hub, prices_csv) into rmsc04.build_config if supported.
    If your rmsc04.build_config doesn't accept them, we fall back cleanly.
    """
    # Build config robustly (works whether rmsc04 accepts extra kwargs or not)
    try:
        config = rmsc04.build_config(
            seed=123,
            date=date,
            log_orders=False,
            hub=hub,
            prices_csv=prices_csv,
        )
    except TypeError:
        # Your rmsc04.build_config signature may not include hub/prices_csv.
        # That's fine as long as rmsc04.py reads the hub prices internally from your loader setup.
        config = rmsc04.build_config(
            seed=123,
            date=date,
            log_orders=False,
        )

    end_state = abides.run(config)

    # Optional debug
    try:
        exch = end_state["agents"][0]  # ExchangeAgent
        print("[DEBUG] exchange order_books keys:", list(exch.order_books.keys())[:10])
    except Exception:
        pass

    return end_state


def run_and_save_agent_features(
    date: str,
    hub: str = "TTF",
    prices_csv: str = "data/eu_hub_prices.csv",
) -> Path:
    """
    Runs ABIDES for one date and saves:
    1) agent-level microstructure features
    2) day-level oracle summary (r_bar)

    Files are hub-namespaced to avoid overwriting across hubs.
    """
    hub = str(hub).strip().upper()

    end_state = run_rmsc04_simulation(date=date, hub=hub, prices_csv=prices_csv)

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # ---------------------------
    # 1) Save agent-level features
    # ---------------------------
    df = extract_agent_features(end_state, date)

    # ensure date is correct + move it to front
    df["date"] = date
    cols = ["date"] + [c for c in df.columns if c != "date"]
    df = df[cols]

    # helpful provenance columns (won't break anything downstream)
    df.insert(0, "hub", hub)

    features_path = OUT_DIR / f"agent_features_{hub}_{date}.csv"
    df.to_csv(features_path, index=False)
    print(f"[OK] Saved {len(df)} rows -> {features_path}")

    # ---------------------------
    # 2) Save oracle day summary
    # ---------------------------
    r_bar = get_r_bar_for_date(date=date, hub=hub, prices_csv=prices_csv)

    summary = pd.DataFrame([{
        "date": date,
        "hub": hub,
        "prices_csv": prices_csv,
        "r_bar": r_bar,                 # ABIDES units
        "r_bar_scaled": r_bar / SCALE,  # back to €/MWh-like units
    }])

    summary_path = OUT_DIR / f"day_summary_{hub}_{date}.csv"
    summary.to_csv(summary_path, index=False)
    print(f"[OK] Saved oracle summary -> {summary_path}")

    return features_path